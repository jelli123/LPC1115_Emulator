/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 3 as
 *  published by the Free Software Foundation.
 */

#ifndef CCS811ITEM_H_
#define CCS811ITEM_H_

#include <sblib/eib/bcu_base.h>
#include <sblib/debounce.h>
#include <sblib/i2c/CCS811.h>

#include <GenericItem.h>
#include <CCS811Config.h>

class CCS811Item : public GenericItem
{
public:
	CCS811Item(byte firstComIndex, CCS811Config* config, GenericItem* nextItem, uint16_t& objRamPointer);
	~CCS811Item() = default;

	void Loop(uint32_t now, int updatedObjectNo);
	int ConfigLength() { return sizeof(CCS811Config); }
	int ComObjCount() { return 5; }

protected:
	CCS811Config *config;
	CCS811Class ccs811;
	uint32_t nextAction = 0;
	byte state = 0;
	bool configured = false;
	uint16_t baseline = 0;
};

#endif /* CCS811ITEM_H_ */
